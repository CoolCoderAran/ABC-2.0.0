HOW TO HTNORMAL2 (x, y):
   WRITE x /
   WRITE y /
