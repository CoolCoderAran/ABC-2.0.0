HOW TO HTSHARED:
   SHARE globalvar
   PUT 5 IN globalvar
