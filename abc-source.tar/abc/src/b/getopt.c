/* This file is slightly adapted from a public domain version. */
/* We need comp.h for the index-strchr controversy. */
#ifdef NOGETOPT

#include "b.h"

/*LINTLIBRARY*/
#define EOF	(-1)
#define ERR(s, c)	if(opterr){\
	char errbuf[2];\
	errbuf[0] = c; errbuf[1] = '\n';\
	VOID write(2, argv[0], (int)strlen(argv[0]));\
	VOID write(2, s, (int)strlen(s));\
	VOID write(2, errbuf, 2);}

int	opterr = 1;
int	optind = 1;
int	optopt = 0;
char	*optarg = 0;

int
getopt(int argc, char **argv, char *opts) {
	static int sp = 1;
	register int c;
	register char *cp;

	if(sp == 1)
		if(optind >= argc ||
		   argv[optind][0] != '-' || argv[optind][1] == '\0')
			return(EOF);
		else if(strcmp(argv[optind], "--") == 0) {
			optind++;
			return(EOF);
		}
	optopt = c = argv[optind][sp];
	if(c == ':' || (cp=strchr(opts, c)) == NULL) {
		ERR(": illegal option -- ", c);
		if(argv[optind][++sp] == '\0') {
			optind++;
			sp = 1;
		}
		return('?');
	}
	if(*++cp == ':') {
		if(argv[optind][sp+1] != '\0')
			optarg = &argv[optind++][sp+1];
		else if(++optind >= argc) {
			ERR(": option requires an argument -- ", c);
			sp = 1;
			return('?');
		} else
			optarg = argv[optind++];
		sp = 1;
	} else {
		if(argv[optind][++sp] == '\0') {
			sp = 1;
			optind++;
		}
		optarg = NULL;
	}
	return(c);
}
#endif

int NO_WARNING = 0;
