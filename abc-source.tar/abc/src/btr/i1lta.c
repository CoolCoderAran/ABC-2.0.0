/* Copyright (c) Stichting Mathematisch Centrum, Amsterdam, 2026. */

/* Access and update lists and tables */

#include "b.h"
#include "bobj.h"
#include "i1btr.h"
#include "i3scr.h" /* For at_nwl */
#include "i1tlt.h"
#include "i1lta.h"

Forward Hidden Procedure killCrange(btreeptr p, value *pv);
Forward Hidden Procedure killIrange(btreeptr p, value *pv);
Forward Hidden Procedure killranges(value *pv);
Forward Hidden Procedure set_size_and_lim(btreeptr pnode);

#define REMOVE_ENTRY	MESS(100, "removing non-existent list entry")

#define REMOVE_RAN	MESS(101, "cannot remove from large range")
#define INSERT_RAN	MESS(102, "cannot insert in large range")

#define KEYS_TAB	MESS(103, "in keys t, t is not a table")

#define SEL_TAB		MESS(104, "in t[k], t is not a table")
#define SEL_KEY		MESS(105, "in t[k], k is not a key of t")

#ifdef BTRTRACE
extern FILE *btrfp;
#endif

#define IsInner(p) (Flag(p) == Inner)
#define IsBottom(p) (Flag(p) == CBottom)

Hidden itemptr Pxitm(btreeptr p, intlet l, literal it){
	return castandgetxitm(p, l, it, IsInner(p) ? Inner : CBottom);
}


#define Inil ((itemptr)0)

#define Incr(p, n) ((p) += (n))

Visible width itemwidth[4]= {Cw, Lw, Tw, Kw};

/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

#define Snil ((fingertip)0)

#define Push(s, p, l) ((s)->s_ptr= (p), ((s)->s_lim= (l)), (s)++)
#undef Top
#define Top(s, p, l) ((p)= ((s)-1)->s_ptr, (l)= ((s)-1)->s_lim)
#define Drop(s) (--(s))
#undef Pop
#define Pop(s, p, l) (--(s), (p)= (s)->s_ptr, (l)= (s)->s_lim)
	/* Pop(s, p, l) is equivalent to Top(s, p, l); Drop(s) */

/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

Visible fingertip unzip(btreeptr p, int at, fingertip s) {
	int syz; intlet l;
	if (p == Bnil) return s;
	for (;;) {
		if (at <= 0) l= 0;
		else if (at >= Size(p)) l= Lim(p);
		else if (IsInner(p)) {
			l= 0;
			while (at > (syz= Size(Ptr(p, l)))) {
				++l;
				at -= syz+1;
			}
		}
		else if (at >= Lim(p)) l= Lim(p) - 1; /* for Irange/Crange */
		else l= at; /* Assume Bottom */
		Push(s, p, l);
		if (!IsInner(p)) break;
		p= Ptr(p, l);
	}
	return s;
}

Visible Procedure cpynptrs(btreeptr *to, btreeptr *from, int n) {
	while (--n >= 0) {
		*to= copybtree(*from);
		Incr(to, 1);
		Incr(from, 1);
	}
}

Visible int movnptrs(btreeptr *to, btreeptr *from, int n) {
	int syz= 0; /* Collects sum of sizes */
	while (--n >= 0) {
		*to= *from;
		syz += Size(*from);
		Incr(to, 1);
		Incr(from, 1);
	}
	return syz;
}

/* The following two routines may prove machine-dependent when moving
   N pointers is not equivalent to moving N*sizeof(pointer) characters.
   Also, the latter may be slower. */

Visible Procedure movnitms(itemptr to, itemptr from, intlet n, intlet iw) {
	register char *t= (char *)to, *f= (char *)from;
	n *= iw;
	while (--n >= 0) *t++ = *f++;
}

Hidden Procedure shift(btreeptr p, intlet l, intlet iw, literal it) {
	/* Move items and pointers from l upwards one to the right */
	btreeptr *to, *from;
	intlet n= (Lim(p)-l) * iw; bool inner= IsInner(p);
	char *f= (char *) Pxitm(p, Lim(p), it);
	char *t= f+iw;
	while (--n >= 0) *--t = *--f;
	if (inner) {
		from= &Ptr(p, Lim(p));
		to= from;
		Incr(to, 1);
		n= Lim(p)-l;
		while (--n >= 0) {
			*to= *from;
			Incr(to, -1);
			Incr(from, -1);
		}
	}
}

Visible Procedure cpynitms(itemptr to, itemptr from, intlet n, intlet it) {
	intlet i, iw= Itemwidth(it);
	movnitms(to, from, n, iw);
	switch (it) {
	case Lt:
	case Kt:
	case Tt:
		for (i= 0; i < n; ++i) {
			copy(Keyval(to));
			if (it == Tt) copy(Ascval(to));
			else if (it == Kt) Ascval(to)= Vnil;
			to= (itemptr) ((char*)to + iw);
		}
	}
}

/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

/* Uflow uses a character array to hold the items.  This may be wrong. */

Visible intlet uflow(intlet n, intlet l, char cbuf[], btreeptr pbuf[], intlet it) {
	char ncbuf[3*Maxbottom*sizeof(btritem)], *cp= ncbuf;
	btreeptr npbuf[3*Maxinner], *pp= npbuf, q;
	intlet iw= Itemwidth(it); bool inner= IsInner(pbuf[0]);
	intlet i, j, k, nn, l1= l>0 ? l-1 : l, l2= l<n ? l+1 : l;
	for (i= l1; i <= l2; ++i) {
		q= pbuf[i]; j= Lim(q);
		cpynitms((itemptr)cp, Pxitm(q, 0, it), j, it);
		cp += j*iw;
		if (inner) {
			cpynptrs(pp, &Ptr(q, 0), j+1);
			Incr(pp, j+1);
		}
		if (i < l2) {
			movnitms((itemptr)cp, (itemptr)(cbuf+i*iw), 1, iw);
			cp += iw;
		}
		relbtree(q, it);
	}
	nn= (cp-ncbuf)/iw;
	k= inner ? Maxinner : Maxbottom;
	if (nn <= k) k= 1;
	else if (nn <= 2*k) k= 2;
	else k= 3;
	/* (k <= l2-l1+1) */
	cp= ncbuf; pp= npbuf;
	for (i= 0; i < k; ++i) {
		if (i > 0) {
			movnitms((itemptr)(cbuf+(l1+i-1)*iw), (itemptr)cp, 1, iw);
			cp += iw;
			--nn;
		}
		pbuf[l1+i]= q= grabbtreenode(inner ? Inner : CBottom, it);
		Lim(q)= Size(q)= j= nn/(k-i); nn -= j;
		movnitms(Pxitm(q, 0, it), (itemptr)cp, j, iw);
		cp += j*iw;
		if (inner) {
			Size(q) += movnptrs(&Ptr(q, 0), pp, j+1);
			Incr(pp, j+1);
		}
	}
	if (k < l2-l1+1) {
		movnitms((itemptr)(cbuf+(l1+k-1)*iw), (itemptr)(cbuf+l2*iw), n-l2, iw);
		VOID movnptrs(pbuf+l1+k, pbuf+l2+1, n-l2);
		n -= l2-l1+1 - k;
	}
	return n;
}

/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

/* Low level access routines */

/* Meaning of 'flags' parameter to searchkey: */
#define NORMAL 0
#define UNIQUE 1 /* uniquify visited nodes */
#define DYAMAX 2 /* special for dyadic max (= previous element) */
#define DYAMIN 4 /* special for dyadic min (= next element) */

Hidden bool searchkey(value v, value *pw, int flags, fingertip *ft) {
	btreeptr p, *pp;
	intlet l, mid, h, it= Itemtype(*pw);
	bool inner; relation r;
	pp= &Root(*pw);
	if (flags&UNIQUE) {
		killranges(pw);
		uniql(pw);
		pp= &Root(*pw);
	}
	if (*pp == Bnil) return No;
	for (;;) {
		if (flags&UNIQUE) uniqlbtreenode(pp, it);
		p= *pp;
		inner= IsInner(p);
		l= 0; h= Lim(p);
		r= 1; /* For the (illegal?) case that there are no items */
		while (l < h) { /* Binary search in {l..h-1} */
			mid= (l+h)/2;
			r= compare(v, Keyval(Pxitm(p, mid, it)));
			if (!comp_ok) return No;
			if (r == 0) { /* Found it */
				if (flags&(DYAMIN|DYAMAX)) {
					/* Pretend not found */
					if (flags&DYAMIN) r= 1;
					else r= -1;
				}
				else { /* Normal case, report success */
					l= mid;
					break;
				}
			}
			if (r < 0) h= mid; /* Continue in {l..mid-1} */
			else if (r > 0) l= mid+1; /* Cont. in {mid+1..h-i} */
		}
		Push(*ft, p, l);
		if (r == 0) return Yes;
		if (!inner) {
			switch (Flag(p)) {
			case Irange: return h > 0 && l < Lim(p) && integral(v);
			case Crange: return h > 0 && l < Lim(p) && character(v);
			default: case CBottom: return No;
			}
		}
		pp= &Ptr(p, l);
	}
}

Hidden Procedure killranges(value *pv) {
	btreeptr p= Root(*pv);
	if (p == Bnil) return;
	switch (Flag(p)) {
	case Crange: killCrange(p, pv); break;
	case Irange: killIrange(p, pv); break;
	}
}

Hidden Procedure killCrange(btreeptr p, value *pv) {
	value w; intlet lwbchar= Lwbchar(p), upbchar= Upbchar(p);
	release(*pv);
	*pv= mk_elt();
	do {
		w= mkchar(lwbchar);
		insert(w, pv);
		release(w);
	} while (++lwbchar <= upbchar);
}

Hidden Procedure killIrange(btreeptr p, value *pv) {
	value w, lwb, upb;

	lwb= copy(Lwbval(p)), upb= copy(Upbval(p));
	release(*pv);
	*pv= mk_elt();
	do {
		insert(lwb, pv);
		if (compare(lwb, upb) >= 0) break;
		w= lwb;
		lwb= sum(lwb, one);
		release(w);
	} while (still_ok);
	release(lwb);
	release(upb);
}

/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

Hidden btreeptr rem(fingertip f, fingertip ft, intlet it) {
	btreeptr p, q, *pp; itemptr ip; intlet l, iw= Itemwidth(it);
	bool inner, underflow;
	Pop(ft, p, l);
	inner= IsInner(p);
	if (!inner) ip= Pbitm(p, l, it);
	else {
		ip= Piitm(p, l, it);
		do {
			Push(ft, p, l);
			uniqlbtreenode(pp= &Ptr(p, l), it);
			p= *pp;
			l= Lim(p);
		} while (IsInner(p));
		inner= No;
		l -= 2; /* So the movnitms below works fine */
	}
	release(Keyval(ip));
	if (it == Tt || it == Kt) release(Ascval(ip));
	--Lim(p);
	movnitms(ip, Pbitm(p, l+1, it), Lim(p)-l, iw);
	for (;;) {
		underflow= Lim(p) < (inner ? Mininner : Minbottom);
		--Size(p);
		if (ft == f) break;
		Pop(ft, p, l);
		if (underflow)
			Lim(p)= uflow(Lim(p), l, (string)Piitm(p, 0, it), &Ptr(p, 0), it);
		inner= Yes;
	}
	if (Lim(p) == 0) { /* Reduce tree level */
		q= p;
		p= inner ? copybtree(Ptr(p, 0)) : Bnil;
		relbtree(q, it);
	}
	return p;
}

Hidden btreeptr ins(itemptr ip, fingertip f, fingertip ft, intlet it) {
	btritem new, old; btreeptr p, q= Bnil, pq, oldq, *pp;
	intlet l, iw= Itemwidth(it), nn, np, nq; bool inner, overflow;
	if (ft == f) {
		/* unify with rest? */
		p= grabbtreenode(CBottom, it);
		movnitms(Pbitm(p, 0, it), ip, 1, iw);
		Lim(p)= Size(p)= 1;
		return p;
	}
	Pop(ft, p, l);
	while (IsInner(p)) {
		Push(ft, p, l);
		uniqlbtreenode(pp= &Ptr(p, l), it);
		p= *pp;
		l= Lim(p);
	}
	overflow= Yes; inner= No;
	for (;;) {
		pq= p;
		if (overflow) {
			oldq= q;
			movnitms(&old, ip, 1, iw);
			ip= &new;
			overflow= Lim(p) == (inner ? Maxinner : Maxbottom);
			if (overflow) {
				nn= Lim(p); np= nn/2; nq= nn-np-1;
				q= grabbtreenode(inner ? Inner : CBottom, it);
				Size(q)= Lim(q)= nq;
				movnitms(&new, Pxitm(p, np, it), 1, iw);
				movnitms(Pxitm(q, 0, it), Pxitm(p, np+1, it), nq, iw);
				if (inner)
					Size(q) += movnptrs(&Ptr(q, 0), &Ptr(p, np+1), nq+1);
				Lim(p)= np;
				Size(p) -= Size(q)+1;
				if (l > np) {
					l -= np+1;
					pq= q;
				}
			}
			shift(pq, l, iw, it);
			movnitms(Pxitm(pq, l, it), &old, 1, iw);
			++Lim(pq);
			if (inner) {
				Size(p) -= Size(oldq);
				Size(pq) += movnptrs(&Ptr(pq, l+1), &oldq, 1);
			}
		}
		++Size(pq);
		if (ft == f) break;
		Pop(ft, p, l);
		inner= Yes;
	}
	if (overflow)
		p= mknewroot(p, ip, q, it);
	return p;
}

/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

/* Tables */

Visible Procedure replace(value a, value *pt, value k) {
	btritem new; finger f; fingertip ft= f; btreeptr p; value *pp;
	intlet it, l;
#ifdef BTRTRACE
	if (btrfp) check(*pt, " (replace in)");
#endif
	if (Is_ELT(*pt)) { (*pt)->type= Tab; Itemtype(*pt)= Tt; }
	it= Itemtype(*pt);
	if (searchkey(k, pt, UNIQUE, &ft)) {
		Pop(ft, p, l);
		pp= &Ascval(Pxitm(p, l, it));
		release(*pp);
		*pp= copy(a);
	}
	else {
		if (!comp_ok) return;
		Keyval(&new)= copy(k); Ascval(&new)= copy(a);
		Root(*pt)= ins(&new, f, ft, it);
	}
#ifdef BTRTRACE
	if (btrfp) check(*pt, " (replace out)");
#endif
}

Visible bool delete(value *pt, value k) {
	finger f; fingertip ft= f; intlet it= Itemtype(*pt);
#ifdef BTRTRACE
	if (btrfp) check(*pt, " (delete in)");
#endif
	if (!searchkey(k, pt, UNIQUE, &ft)) return No;
	Root(*pt)= rem(f, ft, it);
#ifdef BTRTRACE
	if (btrfp) check(*pt, " (delete out)");
#endif
	return Yes;
}

/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

/* Lists */

Hidden bool is_large_range(value v) {
	value s; bool l;
	s= size(v);
	l= large(s);
	release(s);
	return l;
}

Visible Procedure insert(value v, value *pl) {
	btritem new; finger f; fingertip ft= f; intlet it= Itemtype(*pl);
#ifdef BTRTRACE
	if (btrfp) check(*pl, " (insert in)");
#endif
	if (is_large_range(*pl)) {
		interr(INSERT_RAN);
		return;
	}
	if (Is_ELT(*pl)) (*pl)->type= Lis;
	VOID searchkey(v, pl, UNIQUE, &ft);
	if (!comp_ok) return;
	Keyval(&new)= copy(v); Ascval(&new)= Vnil;
	Root(*pl)= ins(&new, f, ft, it);
#ifdef BTRTRACE
	if (btrfp) check(*pl, " (insert out)");
#endif
}

Visible Procedure remove(value v, value *pl) {
	if (is_large_range(*pl)) {
		interr(REMOVE_RAN);
		return;
	}
	if (!delete(pl, v) && still_ok)
		interr(REMOVE_ENTRY);
}

/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

/* Miscellaneous accesses */

Hidden itemptr findkey(value k, value *pv, int flags) {
	finger f; fingertip ft= f; btreeptr p;
	intlet it= Itemtype(*pv), l;
	if (!searchkey(k, pv, flags, &ft)) return Inil;
	Pop(ft, p, l);
	return Pxitm(p, l, it);
}

Visible value associate(value t, value k) { /* t[k] */
	itemptr ip;
	if (!Is_table(t)) {
		interr(SEL_TAB);
		return Vnil;
	}
	ip= findkey(k, &t, NORMAL);
	if (!ip) {
		if (still_ok) /* Could be type error; then shut up! */
			interr(SEL_KEY);
		return Vnil;
	}
	return copy(Ascval(ip));
}

Visible value* adrassoc(value t, value k) { /* &t[k] */
	itemptr ip= findkey(k, &t, NORMAL);
	if (!ip) return Pnil;
	return &Ascval(ip);
}

Visible bool uniq_assoc(value t, value k) { /* uniql(&t[k]) */
	itemptr ip= findkey(k, &t, UNIQUE);
	if (ip == Inil) return No;
	uniql(&Ascval(ip));
	return Yes;
}

Visible bool in_keys(value k, value t) { /* k in keys t */
	return findkey(k, &t, NORMAL) != Inil;
}

Visible value keys(value t) { /* keys t */
	value v;
	if (!Is_table(t)) {
		interr(KEYS_TAB);
		return Vnil;
	}
	v= grab(Lis, Kt);
	Root(v)= copybtree(Root(t));
	return v;
}

/* WARNING!  The following routine is not reentrant, since (for range lists)
   it may return a pointer to static storage. */

Hidden itemptr getkth(int k, value v) {
	finger f; fingertip ft; btreeptr p;
	intlet it= Itemtype(v), l;
	static btritem baked; value vk;
	if (Root(v) == Bnil) return Inil;
	ft= unzip(Root(v), k, f);
	do {
		if (ft == f) return Inil;
		Pop(ft, p, l);
	} while (l >= Lim(p));
	switch (Flag(p)) {
		default:
		case Inner:
		case CBottom:
			return Pxitm(p, l, it);
		case Irange:
			release(Keyval(&baked));
			Keyval(&baked)= sum(Lwbval(p), vk= mk_integer(k));
			release(vk);
			return &baked;
		case Crange:
			release(Keyval(&baked));
			Keyval(&baked)= mkchar(Lwbchar(p) + k);
			return &baked;
	}
}

Visible value* key(value v, intlet k) { /* &(++k th'of keys v) */
	itemptr ip= getkth(k, v);
	return ip ? &Keyval(ip) : Pnil;
}

Visible value* assoc(value v, intlet k) { /* &v[++k th'of keys v] */
	itemptr ip= getkth(k, v);
	return ip ? &Ascval(ip) : Pnil;
}

Visible value thof(int k, value v) { /* k th'of v */
	itemptr ip= getkth(k-1, v);
	if (!ip) return Vnil;
	switch (Type(v)) {
	case Tex: return mkchar(Charval(ip));
	case Lis: return copy(Keyval(ip));
	case Tab: return copy(Ascval(ip));
	default: return Vnil;
	}
}

/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

/* Compare B-trees.  Should use fingers, but to keep things simple
   (especially in the presence of range type nodes), doesn't.  This
   makes its behaviour O(N log N), where it could be O(N), alas. */

/* WARNING!  getkth may return a pointer to static storage (when retrieving
   elements from a range list).  Therefore after the second call to getkth,
   the return value of the first may be invalid, but only for lists.
   So we extract the 'Key' values immediately after the call to getkth. */

Visible relation comp_tlt(value u, value v) {
	itemptr up, vp; int k, ulen, vlen, len; relation r= 0;
	bool tex= Is_text(u), tab= Is_table(u);
	value key_u;
	len= ulen= Tltsize(u); vlen= Tltsize(v);
	if (vlen < len) len= vlen;
	for (k= 0; k < len; ++k) {
		up= getkth(k, u);
		if (!tex) key_u= copy(Keyval(up));
		vp= getkth(k, v);
		if (tex) r= Charval(up) - Charval(vp);
		else {
			r= compare(key_u, Keyval(vp));
			release(key_u);
			if (tab && r == 0)
				r= compare(Ascval(up), Ascval(vp));
		}
		if (r != 0) break;
	}
	if (r == 0) r= ulen - vlen;
	return r;
}

/* Compare texts.  When both texts are bottom nodes, compare with
   strncmp(), to speed up the most common use (look-up by the
   system of tags in a symbol table).  Otherwise, call comp_tlt(). */

Visible relation comp_text(value u, value v) {
	btreeptr p, q; int len; relation r;
	if (!Is_text(u) || !Is_text(v))
		syserr(MESS(106, "comp_text"));
	p= Root(u), q= Root(v);
	if (p EQ Bnil) return (q EQ Bnil) ? 0 : -1;
	if (q EQ Bnil) return 1;
	if (Flag(p) EQ CBottom && Flag(q) EQ CBottom) {
		len= Lim(p);
		if (Lim(q) < len) len= Lim(q);
		r= strncmp(&Bchar(p, 0), &Bchar(q, 0), len);
		if (r NE 0) return r;
		return Lim(p) - Lim(q);
	}
	return comp_tlt(u, v);
}

/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

/* Range type nodes */

Visible bool is_rangelist(value v) {
	return (bool) (Root(v) != Bnil
		       &&
		       (Flag(Root(v)) == Irange || Flag(Root(v)) == Crange)
		      );
}

Hidden value mk_numrange(value lwb, value upb) {
	value lis;
	btreeptr proot;

	lis= grab(Lis, Lt);
	if (numcomp(lwb, upb) > 0)
		Root(lis)= Bnil;
	else {
		Root(lis)= proot= grabbtreenode(Irange, Lt);
		Lwbval(proot)= copy(lwb);
		Upbval(proot)= copy(upb);
		set_size_and_lim(proot);
	}
	return(lis);
}

Hidden value i_range(value lo, value hi) {
	value x, res= Vnil;

	x= diff(lo, hi);
	if (compare(x, one) >= 0)
		res= mk_elt();
	else
		res= mk_numrange(lo, hi);
	release(x);

	return res;
}

Hidden value mk_charrange(value lwb, value upb) {
	value lis;
	btreeptr proot;
	intlet rsyz;

	lis= grab(Lis, Lt);
	rsyz= Bchar(Root(upb), 0) - Bchar(Root(lwb), 0) + 1;
	if (rsyz <= 0)
		Root(lis)= Bnil;
	else {
		Root(lis)= proot= grabbtreenode(Crange, Lt);
		Size(proot)= rsyz;
		Lim(proot)= rsyz > 1 ? 2 : 1;
		Lwbval(proot)= copy(lwb);
		Upbval(proot)= copy(upb);
	}
	return lis;
}


Hidden value c_range(value lo, value hi) {
	char a, z;

	a= charval(lo); z= charval(hi);
	if (z <= a-1) return mk_elt();
	else return mk_charrange(lo, hi);
}

Visible value mk_range(value v1, value v2) {
	if (Is_text(v1)) return c_range(v1, v2);
	else		 return i_range(v1, v2);
}


/* set size and lim for integer range node */

Hidden Procedure set_size_and_lim(btreeptr pnode) {
	value smin, s;
	smin= diff(Upbval(pnode), Lwbval(pnode));
	s= sum(smin, one);
	if (large(s)) {
		Size(pnode)= Bigsize;
		Lim(pnode)= 2;
	}
	else {
		Size(pnode)= intval(s);
		Lim(pnode)= Size(pnode) > 1 ? 2 : 1;
	}
	release(s); release(smin);
}

/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

/* Dyadic min, max, size of lists */

Visible value l2min(value e, value v) { /* e min v */
	finger f; fingertip ft= f; btreeptr p;
	intlet it= Itemtype(v), l;
	VOID searchkey(e, &v, DYAMIN, &ft);
	for (;;) {
		if (ft == f) return Vnil;
		Top(ft, p, l);
		if (l < Lim(p)) {
			switch (Flag(p)) {
			case Inner:
				return copy(Keyval(Piitm(p, l, it)));
			case CBottom:
				return copy(Keyval(Pbitm(p, l, it)));
			case Irange:
				if (l == 0) return copy(Lwbval(p));
				if (integral(e)) return sum(e, one);
				return ceil_f(e);
			case Crange:
				if (l == 0) return copy(Lwbval(p));
				return mkchar(Bchar(Root(e), 0) + 1);
			}
		}
		Drop(ft);
	}
}

Visible value l2max(value e, value v) { /* e max v */
	finger f; fingertip ft= f; btreeptr p;
	intlet it= Itemtype(v), l;
	VOID searchkey(e, &v, DYAMAX, &ft);
	for (;;) {
		if (ft == f) return Vnil;
		Top(ft, p, l);
		--l;
		if (l >= 0) {
			switch (Flag(p)) {
			case Inner:
				return copy(Keyval(Piitm(p, l, it)));
			case CBottom:
				return copy(Keyval(Pbitm(p, l, it)));
			case Irange:
				if (l == 1) return copy(Upbval(p));
				if (integral(e)) return diff(e, one);
				return floor_f(e);
			case Crange:
				if (l == 1) return copy(Upbval(p));
				return mkchar(Bchar(Root(e), 0) - 1);
			}
		}
		Drop(ft);
	}
}

Visible int l2size(value e, value v) { /* e#v */
	finger f; fingertip ft= f; btreeptr p;
	int count= 0; intlet it= Itemtype(v), l, r;
	VOID searchkey(e, &v, DYAMIN, &ft);
	for (;;) {
		if (ft == f) return count;
		Pop(ft, p, l);
		while (--l >= 0) {
			r= compare(Keyval(Pxitm(p, l, it)), e);
			if (r != 0) {
				switch (Flag(p)) {
				case Irange: /* See footnote */
					if (l==0 && count==0 && integral(e))
						++count;
					break;
				case Crange: /* See footnote */
					if (l==0 && count==0 && !character(e))
						++count;
					break;
				}
				return count;
			}
			++count;
			while (IsInner(p)) {
				Push(ft, p, l);
				p= Ptr(p, l);
				l= Lim(p);
			}
		}
	}
}

/* Clarification of what happens for x#{a..b}:
 * Consider these five cases: x<a; x=a; a<x<b; x=b; b<x.
 * Only the case a<x<b need be treated specially.  How do we find which
 * case we're in?
 * Searchkey gives us the following values for l on the stack, respectively:
 * 0; 1; 1; 2; 2.  After --l, this becomes -1; 0; 0; 1; 1.
 * In cases x=a or x=b, the compare returns 0, and we go another time
 * through the loop.  So when the compare returns r!=0, the value of l
 * is, respectively: -1; -1; 0; 0; 1.  The -1 cases in fact don't even
 * get at the compare, and the correct count is returned automatically.
 * So we need to do extra work only if l==0, except if x==b.
 * The latter condition is cared for by count==0 (if x==b, count is
 * surely >= 1; if a<x<b, count is surely 0).  This works even when
 * range nodes may be mixed with other node types in one tree.
 */

/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

#ifdef BTRTRACE
/* Debug code */

Hidden Procedure check(value v, string whence) {
	if (!still_ok) return;
	switch (Type(v)) {
	case ELT:
		return;
	case Lis:
	case Tab:
		break;
	default:
		debugbtr("value not a list or table", whence);
		return;
	}
	if (Root(v) != Bnil)
		VOID cktree(Inil, Root(v), Inil, Itemtype(v), whence);
	if (!still_ok && !Interrupted()) {
		dumptree(Root(v), 0, Itemtype(v));
		fputc('\n', btrfp);
		VOID fflush(btrfp);
	}
}

Hidden int cktree(itemptr left, btreeptr p, itemptr right, intlet it, string whence) {
	/* returns size of checked subtree */
	intlet i, iw= Itemwidth(it); int sz= 0;
	if (!still_ok) return 0;
	if (p == Bnil) {
		debugbtr("unexpected nil subtree", whence);
		return 0;
	}
	switch (Flag(p)) {
	case Inner:
		for (i= 0; i < Lim(p); ++i) {
			sz += 1 +
			  cktree(left, Ptr(p, i), Piitm(p, i, iw), it, whence);
			if (!still_ok) return 0;
			left= Piitm(p, i, iw);
		}
		sz += cktree(left, Ptr(p, i), right, it, whence);
		if (still_ok && sz != Size(p))
			debugbtr("size mismatch", whence);
		break;
	case CBottom:
		for (i= 0; i < Lim(p); ++i) {
			if (left != Inil && compare(Keyval(left),
					Keyval(Pbitm(p, i, iw))) > 0) {
				debugbtr("bottom items out of order", whence);
				break;
			}
			left= Pbitm(p, i, iw);
			sz++;
		}
		if (still_ok && right != Inil
			&& compare(Keyval(left), Keyval(right)) > 0)
				debugbtr("bottom items out of order", whence);
		return sz;
	case Irange:
		if (left != Inil && compare(Keyval(left), Lwbval(p)) > 0
			|| right != Inil
				&& compare(Upbval(p), Keyval(right)) > 0)
			debugbtr("irange items out of order", whence);
		sz= Size(p);
	default:
		debugbtr("bad node type", whence);
	}
	return sz;
}

Hidden Procedure dumptree(btreeptr p, intlet indent, intlet it) {
	intlet i, iw= Itemwidth(it);
	int n;
	if (Interrupted()) return;
	for (n= 0; n<3*indent; n++)
		fputc(' ', btrfp);
	if (p == Bnil) {
		fputs("<nil>", btrfp);
		return;
	}
	switch (Flag(p)) {
	case Inner:
		fputs("(\n", btrfp);
		for (i= 0; !Interrupted() && i <= Lim(p); ++i) {
			if (i > 0) {
				for (n= 0; n<3*indent; n++)
					fputc(' ', btrfp);
				dumpval(Keyval(Piitm(p, i-1, iw)));
				fputc('\n', btrfp);
			}
			dumptree(Ptr(p, i), indent+1, it);
			fputc('\n', btrfp);
		}
		for (n= 0; n<3*indent; n++)
			fputc(' ', btrfp);
		fputc(')', btrfp);
		break;
	case CBottom:
		fputc('[', btrfp);
		for (i= 0; i < Lim(p); ++i) {
			if (i > 0) fputc(' ', btrfp);
			dumpval(Keyval(Pbitm(p, i, iw)));
		}
		fputc(']', btrfp);
		break;
	case Irange:
		fputc('{', btrfp);
		dumpval(Lwbval(p));
		fputs(" .. ", btrfp);
		dumpval(Upbval(p));
		fputc('}', btrfp);
		break;
	default:
		fprintf(btrfp, "?type='%c'?", Flag(p));
		break;
	}
}

Hidden Procedure dumpval(value v) {
	if (Interrupted()) return;
	if (v == Vnil) fputs("(nil)", btrfp);
	else switch(Type(v)) {
	case Num: case Tex: case Lis: case Tab: case ELT: case Com:
		wri(btrfp, v, No, No, No);
		break;
	default:
		fprintf(btrfp, "0x%lx", (long)v);
	}
}

Hidden Procedure debugbtr(string s1, string s2) {
	value v1= mk_text(s1);
	value v2= mk_text(s2);
	value v= concat(v1, v2);
	interrV(-1, v);
	release(v1); release(v2);
	release(v);
}

#endif /* BTRTRACE */

